function myFunction(){
      var obj1= document.getElementById("contentsecond");
      obj1.style.filter="blur(10px)";
      var obj2 =document.getElementById("JUST__GO__ON");
      obj2.style.filter="blur(1px)";
        var obj3 =document.getElementById("textinput");
       obj3.value=" ";
       var obj4 =document.getElementById("iTenzor");
      obj4.style.filter="blur(1px)";
}

function bind(obj,eventStr,callback){
	if(obj.addEventListener){
		obj.addEventListener(eventStr,callback,false);
	}else{
		//obj.attachEvent("on"+eventStr,callback);
		//统一执行顺序：callback.call(obj)
		obj.attachEvent("on"+eventStr,function(){
			callback.call(obj);
		});    
	}
}	









function myFunction2(){
    var obj1= document.getElementById("contentsecond");
      obj1.style.filter="blur(0px)";
      var obj2 =document.getElementById("JUST__GO__ON");
      obj2.style.filter="blur(0px)";
      var obj4 =document.getElementById("iTenzor");
      obj4.style.filter="blur(0px)";
}






//function fontsize(){
/// var box1=document.getElementById("JUST__GO__ON");
 //box1.onmousewheel=function(event){
  //  console.log("滚了")
//}
//ox1.addEventListener("DOMMouseScroll",function(){
  //  console.log(333)	})
  //  box1.addEventListener("DOMMouseScroll",box1.onmousewheel)
   // bind(box1,"DOMMouseScroll",box1.onmousewheel);
   // box1.addEventListener("wheel",function(){
    //    console.log(1111)})
     //   bind(box1,"wheel",function(){
      //      console.log(1111)});




      //var fontSize1=window.getComputedStyle(box1,null).getPropertyValue('font-size')
      window.onload=function(){
        event=event||window.event;
        var box1=document.getElementById("JUST__GO__ON");
        var box2=document.getElementById("iTenzor");
        box1.onmousewheel=function(event1){if (box1.style.fontSize<=500+"px" ) {
			
				box1.style.fontSize=box1.clientHeight +1+"px";	return false;
       
		} else{
			
     box1.style.fontSize=0+"px";
     box2.style.fontSize=600+"px";
    box2.onmousewheel=function(event2){if (box2.style.fontSize>=15+"px" ){
      box2.style.fontSize=box2.clientHeight *(0.20)+"px";	
      return false;
     }
      else{
        box2.style.fontSize=14+"px"
      }
    }
      return false;
     }




     function picturechange(){
      var BOX=document.getElementsByClassName("BOX")
      var p1=document.getElementById("图层_4");
      var p2=document.getElementById("图层_9");
      var p3=document.getElementById("图层_5");
      var p4=document.getElementById("图层_8");
      var p5=document.getElementById("图层_7");
     
    p1.onmousewheel=function(act1){
if(p1.style.left<=200+"px"){
  p1.style.left=p1.clientLeft+1+"px";
}else{p1.style.left=189+"px"}





    }
    
    
    
    
    
    
    }






     
     




     	
		
        event.preventDefault && event.preventDefault();
         
        }}
        
            
        
      


       
       ;
       //var word1=document.getElementById("JUST__GO__ON")
//var fontSize1=window.getComputedStyle(word1,null).getPropertyValue('font-size')
 //    function wordchang(){
//  word1.addEventListener
//  if(fontSize1<=50+"px"){
//    word1.onmousewheel=function(event){if (event.wheelDelta>0 || event.detail<0) {
//			//向上滚动  word1变短
	//		word1.style.fontSize=word1.clientHeight-1+"px";	
//		} else{
//			//向下滚动 word1变长
//			word1.style.fontSize=word1.clientHeight+1+"px";	
 //     event.preventDefault && event.preventDefault();
  //      return false;}}
   // }
//}
let backTop=document.querySelector('.backimg')
  window.addEventListener('scroll',displayReaturnTop);
function displayReaturnTop(e){
  console.log(scrollY);
  if(window.scrollY>200){
    backTop.style.display="none";}
  else{
    backTop.style.display='none';}
  }



    backTop.addEventListener('click',ReturnTop);
    function ReturnTop(){
      scrollTo({
        top:0,
        behavior:"smooth"
      })
    }
  










    

       //返回顶部和返回头部
       $("#backtotop").each(function() {
        $(this).find(".gotop").click(function() {
            $("html, body").animate({
                    "scroll-top": 0
                },
                "fast")
        });
        //如果页面中包含grade样式则跳转到grade，否则跳转到footer位置
        $(".gobottom").click(function() {
            if ($(".grade").length) {
                $("html, body").animate({
                    scrollTop: $(".grade").offset().top - ($(window).height() - $(".grade").outerHeight()) / 2
                }, 800);
            } else {
                $("html, body").animate({
                    scrollTop: $(".footer").offset().top
                }, 800);
            }
            return false;
        });
    });
    var d = false;
    $(window).scroll(function() {
        var j = $(window).scrollTop();
        if (j > 500) {
            $("#backtotop").data("expanded", true)
        } else {
            $("#backtotop").data("expanded", false)
        }
        if ($("#backtotop").data("expanded") != d) {
            d = $("#backtotop").data("expanded");
            if (d) {
                $("#backtotop .gotop").slideDown()
            } else {
                $("#backtotop .gotop").slideUp()
            }
        }
    });